from __future__ import annotations

import logging
from typing import Any, Dict, Set, Optional
from boto3 import Session
from botocore.exceptions import ClientError
from mypy_boto3_s3 import S3Client
from mypy_boto3_s3.type_defs import (
    GetBucketLocationOutputTypeDef,
    GetBucketTaggingOutputTypeDef,
    HeadBucketOutputTypeDef,
    HeadObjectOutputTypeDef,
)

from resolvers.base import BaseResolver
from graph.dependency_graph import ResourceNode
from utils.arn import ARN

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def is_service_managed_bucket(bucket_name: str) -> bool:
    """
    Detect AWS-managed or service-linked S3 buckets.
    """
    prefixes = (
        "aws-",                    # generic AWS internal buckets
        "amazon-connect-",         # Connect buckets (recordings/prompts)
        "aws-glue-",               # Glue logs/temp
        "aws-athena-query-results",# Athena
        "logs-",                   # CloudTrail / service logs
    )
    return bucket_name.startswith(prefixes)


def parse_s3_parts(arn: ARN) -> tuple[str, Optional[str]]:
    """
    Split arn:aws:s3:::bucket[/key] into (bucket, key).
    """
    if not arn.resource:
        raise ValueError(f"Invalid S3 ARN: {arn}")
    parts = arn.resource.split("/", 1)
    bucket = parts[0]
    key = parts[1] if len(parts) > 1 else None
    return bucket, key


# ---------------------------------------------------------------------------
# Resolver
# ---------------------------------------------------------------------------

class S3Resolver(BaseResolver[S3Client, Dict[str, Any]]):
    """Resolver for S3 buckets and objects."""

    def fetch(self, arn: ARN) -> Dict[str, Any]:
        bucket, key = parse_s3_parts(arn)
        result: Dict[str, Any] = {"Bucket": bucket, "Key": key, "Arn": str(arn)}

        # Skip service-managed buckets
        if is_service_managed_bucket(bucket):
            result["ManagedBy"] = "AWS"
            result["Implicit"] = True
            result["Exists"] = True
            result["ServiceManaged"] = True
            logger.info("[S3Resolver] Skipping fetch for service-managed bucket %s", bucket)
            return result

        try:
            if key:
                # -------------------------------
                # S3 Object case
                # -------------------------------
                head_obj: HeadObjectOutputTypeDef = self.client.head_object(Bucket=bucket, Key=key)
                result.update(
                    {
                        "Exists": True,
                        "ObjectSize": head_obj.get("ContentLength"),
                        "ContentType": head_obj.get("ContentType"),
                        "ETag": head_obj.get("ETag"),
                        "LastModified": head_obj.get("LastModified"),
                        "ManagedBy": "Customer",
                        "IsObject": True,
                    }
                )
            else:
                # -------------------------------
                # S3 Bucket case
                # -------------------------------
                region_resp: GetBucketLocationOutputTypeDef = self.client.get_bucket_location(Bucket=bucket)
                region = region_resp.get("LocationConstraint") or "us-east-1"
                result["Region"] = region

                try:
                    tags_resp: GetBucketTaggingOutputTypeDef = self.client.get_bucket_tagging(Bucket=bucket)
                    result["Tags"] = tags_resp.get("TagSet", [])
                except ClientError as e:
                    if e.response["Error"]["Code"] not in ("NoSuchTagSet", "AccessDenied"):
                        raise
                    result["Tags"] = []

                head: HeadBucketOutputTypeDef = self.client.head_bucket(Bucket=bucket)
                result.update({"Exists": True, "ManagedBy": "Customer", "IsObject": False})

        except ClientError as e:
            logger.warning("[S3Resolver] Failed to fetch %s: %s", arn, e)
            result.update({"Error": str(e), "Exists": False})

        return result

    # ------------------------------------------------------------------
    # Parse
    # ------------------------------------------------------------------
    def parse(self, arn: ARN, raw: Dict[str, Any]) -> ResourceNode:
        bucket = raw.get("Bucket")
        key = raw.get("Key")
        is_object = bool(key)
        refs: Set[ARN] = set()

        implicit = raw.get("Implicit", False)
        service_managed = raw.get("ServiceManaged", False)
        aws_managed = is_service_managed_bucket(bucket)

        if is_object and bucket:
            # Add dependency edge from object → bucket
            refs.add(ARN(f"arn:aws:s3:::{bucket}"))

        if service_managed or aws_managed:
            reference_only = True
            managed_by = "AWS"
        else:
            reference_only = False
            managed_by = "Customer"

        if is_object:
            # -------------------------------
            # Object Node
            # -------------------------------
            props: Dict[str, Any] = {
                "Bucket": bucket,
                "Key": key,
                "Size": raw.get("ObjectSize"),
                "ContentType": raw.get("ContentType"),
                "ETag": raw.get("ETag"),
                "ManagedBy": managed_by,
                "Exists": raw.get("Exists"),
            }

            metadata: Dict[str, Any] = {
                "IsObject": True,
                "Implicit": implicit,
                "ServiceManaged": service_managed,
                "Error": raw.get("Error"),
            }

            return ResourceNode(
                logical_id=f"S3Object{bucket.replace('-', '')}_{key.replace('/', '_').replace('-', '_')[:80]}",
                service="s3",
                cfn_type="AWS::S3::Object",
                properties=props,
                referenced_arns=refs,
                arns={"Object": arn},
                reference_only=reference_only or implicit,
                metadata=metadata,
            )

        # -------------------------------
        # Bucket Node
        # -------------------------------
        props: Dict[str, Any] = {
            "BucketName": bucket,
            "Region": raw.get("Region"),
            "Tags": raw.get("Tags", []),
            "ManagedBy": managed_by,
        }

        metadata: Dict[str, Any] = {
            "IsObject": False,
            "Implicit": implicit,
            "Exists": raw.get("Exists", True),
            "Error": raw.get("Error"),
        }

        if aws_managed or implicit:
            metadata["Reason"] = "Service-linked managed bucket"

        return ResourceNode(
            logical_id=f"S3Bucket{bucket.replace('-', '').replace('_', '')}",
            service="s3",
            cfn_type="AWS::S3::Bucket",
            properties=props,
            referenced_arns=refs,
            arns={"Bucket": arn},
            reference_only=reference_only,
            metadata=metadata,
        )
